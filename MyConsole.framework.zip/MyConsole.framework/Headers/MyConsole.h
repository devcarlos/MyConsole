//
//  MyConsole.h
//  MyConsole
//
//  Created by Carlos Alcala on 2/8/20.
//  Copyright © 2020 Kurrentap. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MyConsole.
FOUNDATION_EXPORT double MyConsoleVersionNumber;

//! Project version string for MyConsole.
FOUNDATION_EXPORT const unsigned char MyConsoleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MyConsole/PublicHeader.h>


